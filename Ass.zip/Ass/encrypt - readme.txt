The file encrypt.hs is a command line program that takes a file name and an index from 1 to 26 and it encrypts the file with a Caesar cipher using the value of the index.
Every letter will be switched by the value of the index.
For instance, if the index is 3, the sentence
"hi anna"
will be changed into 
"kl dppn".
Characters that are not letters are unchanged. Capital letters are first converted to lower case letters before encrypting.
